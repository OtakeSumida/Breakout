var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["81e79b8f-23b2-4fb7-98cf-b1f49ebfbc62","e93dc922-fac5-453f-b595-7377830dc153","1bfef88f-63a4-49ae-84dc-12a7c375a319","136af5c7-c09c-4ef1-8138-09a1d267bacf","30555a5a-3340-4876-866f-13f90ba5db97"],"propsByKey":{"81e79b8f-23b2-4fb7-98cf-b1f49ebfbc62":{"name":"background_landscape26_1","sourceUrl":"assets/api/v1/animation-library/gamelab/qerN0VWVdOLmI2WvXaDIpUO60eJ_eNII/category_backgrounds/background_landscape26.png","frameSize":{"x":400,"y":390},"frameCount":1,"looping":true,"frameDelay":2,"version":"qerN0VWVdOLmI2WvXaDIpUO60eJ_eNII","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":390},"rootRelativePath":"assets/api/v1/animation-library/gamelab/qerN0VWVdOLmI2WvXaDIpUO60eJ_eNII/category_backgrounds/background_landscape26.png"},"e93dc922-fac5-453f-b595-7377830dc153":{"name":"face_softserve_1","sourceUrl":"assets/api/v1/animation-library/gamelab/yhHelTG25c6afcwdqkBrnqeEyFW7V0oZ/category_food/face_softserve.png","frameSize":{"x":200,"y":393},"frameCount":1,"looping":true,"frameDelay":2,"version":"yhHelTG25c6afcwdqkBrnqeEyFW7V0oZ","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":200,"y":393},"rootRelativePath":"assets/api/v1/animation-library/gamelab/yhHelTG25c6afcwdqkBrnqeEyFW7V0oZ/category_food/face_softserve.png"},"1bfef88f-63a4-49ae-84dc-12a7c375a319":{"name":"face_popcorn_1","sourceUrl":"assets/api/v1/animation-library/gamelab/ApUUYO3Nr0tF9XPM7qx9KqT81lx3Ml4U/category_food/face_popcorn.png","frameSize":{"x":257,"y":394},"frameCount":1,"looping":true,"frameDelay":2,"version":"ApUUYO3Nr0tF9XPM7qx9KqT81lx3Ml4U","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":257,"y":394},"rootRelativePath":"assets/api/v1/animation-library/gamelab/ApUUYO3Nr0tF9XPM7qx9KqT81lx3Ml4U/category_food/face_popcorn.png"},"136af5c7-c09c-4ef1-8138-09a1d267bacf":{"name":"ball","sourceUrl":"assets/api/v1/animation-library/gamelab/2O84JtbnWjil7f2R0oUqvFTRHnFaGCIw/category_food/face_strawberry.png","frameSize":{"x":310,"y":399},"frameCount":1,"looping":true,"frameDelay":2,"version":"2O84JtbnWjil7f2R0oUqvFTRHnFaGCIw","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":310,"y":399},"rootRelativePath":"assets/api/v1/animation-library/gamelab/2O84JtbnWjil7f2R0oUqvFTRHnFaGCIw/category_food/face_strawberry.png"},"30555a5a-3340-4876-866f-13f90ba5db97":{"name":"rpgcharacter_11_1","sourceUrl":"assets/api/v1/animation-library/gamelab/8AmDG487lonn5isbI5elQ3ee8xDHqDsZ/category_fantasy/rpgcharacter_11.png","frameSize":{"x":252,"y":332},"frameCount":1,"looping":true,"frameDelay":2,"version":"8AmDG487lonn5isbI5elQ3ee8xDHqDsZ","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":252,"y":332},"rootRelativePath":"assets/api/v1/animation-library/gamelab/8AmDG487lonn5isbI5elQ3ee8xDHqDsZ/category_fantasy/rpgcharacter_11.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var sky = createSprite(200, 200);
sky.setAnimation("background_landscape26_1");
var box1 = createSprite(25, 75, 50, 50);
box1.setAnimation("face_softserve_1");
var box2 = createSprite(75, 75, 50, 50);
box2.setAnimation("face_popcorn_1");
var box3 = createSprite(125, 75, 50, 50);
box3.setAnimation("face_softserve_1");
var box4 = createSprite(175, 75, 50, 50);
box4.setAnimation("face_popcorn_1")
var box5 = createSprite(225, 75, 50, 50);
box5.setAnimation("face_softserve_1");
var box6 = createSprite(275, 75, 50, 50);
box6.setAnimation("face_popcorn_1");
var box7 = createSprite(325, 75, 50, 50);
box7.setAnimation("face_softserve_1");
var box8 = createSprite(375, 75, 50, 50);
box8.setAnimation("face_popcorn_1");


var box9 = createSprite(25, 125, 50, 50);
box9.setAnimation("face_softserve_1")
var box10 = createSprite(75, 125, 50, 50);
box10.setAnimation("face_popcorn_1")
var box11 = createSprite(125, 125, 50, 50);
box11.setAnimation("face_softserve_1");
var box12 = createSprite(175, 125, 50, 50);
box12.setAnimation("face_popcorn_1");
var box13 = createSprite(225,125, 50, 50);
box13.setAnimation("face_softserve_1")
var box14 = createSprite(275, 125, 50, 50);
box14.setAnimation("face_popcorn_1");
var box15 = createSprite(325, 125, 50, 50);
box15.setAnimation("face_softserve_1")
var box16 = createSprite(375, 125, 50, 50);
box16.setAnimation("face_popcorn_1")

box1.scale = 0.2;
box2.scale = 0.2;
box3.scale = 0.2;
box4.scale = 0.2;
box5.scale = 0.2;
box6.scale = 0.2;
box7.scale = 0.2;
box8.scale = 0.2;
box9.scale = 0.2;
box10.scale = 0.2;
box11.scale = 0.2;
box12.scale = 0.2;
box13.scale = 0.2;
box14.scale = 0.2;
box15.scale = 0.2;
box16.scale = 0.2;

paddle=createSprite(200,350,100,20)
ball=createSprite(200,200,20,20)
createEdgeSprites();

function draw() {
  background("white");
  //movimnetação com mouse
  paddle.x = World.mouseX;
  if (keyDown("space")) {
    ball.velocityX = 3;
    ball.velocityY = 3;
  }
  
  ball.bounceOff(edges);
  //
  if (ball.isTouching(box1)) {
    box1.destroy();
    
  }
  if (ball.isTouching(box2)) {
    box2.destroy();
    
  }
  if (ball.isTouching(box3)) {
    box3.destroy();
    
  }
  if (ball.isTouching(box4)) {
    box4.destroy();
    
  }
  if (ball.isTouching(box5)) {
    box5.destroy();
    
  }
  if (ball.isTouching(box6)) {
    box6.destroy();
    
  }
  if (ball.isTouching(box7)) {
    box7.destroy();
    
  }
  if (ball.isTouching(box8)) {
    box8.destroy();
    
  }
  if (ball.isTouching(box9)) {
    box9.destroy();
    
  }
  if (ball.isTouching(box10)) {
    box10.destroy();
    
  }
  if (ball.isTouching(box11)) {
    box11.destroy();
    
  }
  if (ball.isTouching(box12)) {
    box12.destroy();
    
  }
  if (ball.isTouching(box13)) {
    box13.destroy();
    
  }
  if (ball.isTouching(box14)) {
    box14.destroy();
    
  }
  if (ball.isTouching(box15)) {
    box15.destroy();
    
  }
  if (ball.isTouching(box16)) {
    box16.destroy();
    
  }
  // 
  // 
  // 
  drawSprites();
}

ball.setAnimation("ball");
paddle.setAnimation("rpgcharacter_11_1");
paddle.scale = 0.3;
ball.scale=0.1;
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
